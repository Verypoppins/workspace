console.log("Archivo JS cargado correctamente");
alert("¡Hola este es el archivo1.js!");
